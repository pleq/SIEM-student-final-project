module.exports = function (scope, modal) {
    scope.showSigmaChooser = function () {
        let modalClass = 'select-sigma';
        modal.show(scope, {
            title: 'Search Sigma Rules',
            body: '<div sp-select-sigma modal-class="' + modalClass + '" curr-url="currUrl" curr-sigma="currSigma"></div>',
            size: 'large',
            actions: [{
                label: 'Cancel',
                cssClass: 'btn-outline-danger',
                onClick: function (e) {
                    $(e.target).parents('.modal').modal('hide');
                }
            }, {
                label: 'Open in Editor',
                savingLabel: 'Saving...',
                cssClass: 'btn-submit btn-outline-danger disabled',
                onClick: function (event) {
                    if (!$(event.target).hasClass('disabled')) {
                        $(event.target).parents('.modal').find('.' + modalClass + ' form').trigger('sw.apply_form');
                    }
                }
            }]
        });
    };

    scope.clearEditor = function () {
        scope.currSigma = {
            json: scope.emptySigmaJson || {},
            sigma_text: scope.emptySigmaText || ''
        };
    };

    scope.exportToSiem = function (siemSlug, siemName) {
        let convertToSiem = 'convert-to-siem';
        modal.show(scope, {
            title: 'Conver to ' + siemName,
            body: '<div sp-convert-to-siem curr-url="currUrl" form-class="' + convertToSiem + '" siem-slug="' + siemSlug + '" curr-sigma-text="currSigma.sigma_text"></div>',
            actions: [{
                label: 'Cancel',
                cssClass: 'btn btn-outline-danger',
                onClick: function (e) {
                    $(e.target).parents('.modal').modal('hide');
                }
            }, {
                label: 'Copy to clipboard',
                savingLabel: 'Copying...',
                cssClass: 'btn btn-submit btn-outline-danger copy-to-clipboard',
                onClick: function (event) {
                    if (!$(event.target).hasClass('disabled')) {
                        $(event.target).parents('.modal').find('.' + convertToSiem + ' form').trigger('sw.apply_form');
                    }
                }
            }]
        });
    };
};