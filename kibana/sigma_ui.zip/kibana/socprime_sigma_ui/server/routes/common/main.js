/**
 * @param server
 * @param options
 */
export default function (server, options) {
    const index = (req) => {
        return {
            success: true
        };
    };

    return {
        index: index
    };
};
